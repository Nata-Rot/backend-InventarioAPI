﻿using System;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace InventarioAPI.Models
{
    public class Usuario
    {
        public int UsuarioID { get; set; } // Identificador único
        public string Email { get; set; } // Correo electrónico único
        public string PasswordHash { get; set; } // Contraseña encriptada
        public string Nombre { get; set; } // Nombre del usuario
        public DateTime FechaRegistro { get; set; } = DateTime.Now; // Fecha de registro
        public bool Activo { get; set; } = true; // Usuario activo o no
    }

}
