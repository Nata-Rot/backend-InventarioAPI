﻿using Microsoft.EntityFrameworkCore;
using InventarioAPI.Models;

namespace InventarioAPI.Data
{
    public class ApplicationDbContext : DbContext
    {
        public ApplicationDbContext(DbContextOptions<ApplicationDbContext> options) : base(options)
        {
        }

        public DbSet<Producto> Producto { get; set; }
        public DbSet<EntradaInventario> EntradaInventario { get; set; }
        public DbSet<Usuario> Usuarios { get; set; } // Agrega la tabla de usuarios

        public DbSet<SalidaInventario> SalidaInventario { get; set; }

        protected override void OnModelCreating(ModelBuilder modelBuilder)
        {
            base.OnModelCreating(modelBuilder);

            // Configuración explícita para la tabla SalidaInventario
            modelBuilder.Entity<SalidaInventario>()
                .ToTable("SalidaInventario"); // Especifica el nombre correcto de la tabla
        }

    }
}
