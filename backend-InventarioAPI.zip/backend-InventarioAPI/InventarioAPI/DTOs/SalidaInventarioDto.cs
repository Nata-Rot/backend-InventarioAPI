﻿namespace InventarioAPI.DTOs
{
    public class SalidaInventarioDTO
    {
        public int ProductoId { get; set; }
        public int Cantidad { get; set; }
    }
}