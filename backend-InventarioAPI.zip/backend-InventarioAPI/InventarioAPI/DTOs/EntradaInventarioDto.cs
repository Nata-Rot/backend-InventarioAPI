﻿namespace InventarioAPI.DTOs
{
    public class EntradaInventarioDTO
    {
        public int ProductoId { get; set; }
        public int Cantidad { get; set; }
        public DateTime FechaCaducidad { get; set; }
    }

}
