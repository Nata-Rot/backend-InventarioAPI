﻿using InventarioAPI.Data;
using InventarioAPI.DTOs;
using InventarioAPI.Models;
using System;
using System.Linq;

namespace InventarioAPI.Services
{
    public class SalidaInventarioService
    {
        private readonly ApplicationDbContext _context;

        public SalidaInventarioService(ApplicationDbContext context)
        {
            _context = context;
        }

        public int CrearSalida(SalidaInventarioDTO salida)
        {
            // Verificar cantidad disponible en inventario
            var cantidadDisponible = _context.EntradaInventario
                .Where(e => e.ProductoId == salida.ProductoId)
                .Sum(e => e.Cantidad);

            Console.WriteLine($"Cantidad disponible para producto {salida.ProductoId}: {cantidadDisponible}");
            Console.WriteLine($"Cantidad solicitada para salida: {salida.Cantidad}");

            if (cantidadDisponible < salida.Cantidad)
            {
                throw new Exception("Cantidad insuficiente para realizar la salida.");
            }

            // Proceder a realizar la salida de inventario
            var salidaInventario = new SalidaInventario
            {
                ProductoId = salida.ProductoId,
                Cantidad = salida.Cantidad,
                FechaSalida = DateTime.Now
            };

            // Registrar la salida en la base de datos
            _context.SalidaInventario.Add(salidaInventario);

            var entradasProducto = _context.EntradaInventario
                .Where(e => e.ProductoId == salida.ProductoId)
                .OrderBy(e => e.FechaEntrada)
                .ToList();

            foreach (var entrada in entradasProducto)
            {
                if (salida.Cantidad <= 0)
                    break;

                if (entrada.Cantidad >= salida.Cantidad)
                {
                    entrada.Cantidad -= salida.Cantidad;
                    salida.Cantidad = 0;
                }
                else
                {
                    salida.Cantidad -= entrada.Cantidad;
                    entrada.Cantidad = 0;
                }
            }

            _context.SaveChanges();

            // Retornar el ID de la salida registrada
            return salidaInventario.Id;
        }

    }
}
