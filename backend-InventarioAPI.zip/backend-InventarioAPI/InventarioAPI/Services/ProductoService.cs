﻿using System;
using System.Linq;
using InventarioAPI.Models;
using InventarioAPI.Data;
using InventarioAPI.DTOs;
using System.Collections;

namespace GestionInventario.Services
{
    public class ProductoService
    {
        private readonly ApplicationDbContext _context;

        public ProductoService(ApplicationDbContext context)
        {
            _context = context;
        }

        public IEnumerable GetProductos()
        {
            return _context.Producto
                .Select(p => new ProductoDTO
                {
                    Id = p.Id,
                    Nombre = p.Nombre,
                    Descripcion = p.Descripcion,
                    FechaCreacion = p.FechaCreacion
                }).ToList();
        }
        public ProductoDTO GetProductoById(int id)
        {
            var producto = _context.Producto
                .Where(p => p.Id == id)
                .Select(p => new ProductoDTO
                {
                    Id = p.Id,
                    Nombre = p.Nombre,
                    Descripcion = p.Descripcion,
                    FechaCreacion = p.FechaCreacion
                }).FirstOrDefault();

            return producto;
        }
        public ProductoDTO CrearProducto(ProductoDTO productoDto)
        {
            var producto = new Producto
            {
                Nombre = productoDto.Nombre,
                Descripcion = productoDto.Descripcion,
                FechaCreacion = DateTime.Now, // Set creation date automatically
                CantidadDisponible = productoDto.CantidadDisponible
            };

            _context.Producto.Add(producto);
            _context.SaveChanges();

            // Map back to DTO to return
            return new ProductoDTO
            {
                Id = producto.Id,
                Nombre = producto.Nombre,
                Descripcion = producto.Descripcion,
                FechaCreacion = producto.FechaCreacion,
                CantidadDisponible = producto.CantidadDisponible
            };
        }
        public bool EliminarProducto(int id)
        {
            var producto = _context.Producto.Find(id);
            if (producto == null)
            {
                return false;  // Si no se encuentra el producto, retorna falso
            }

            _context.Producto.Remove(producto);  // Eliminar el producto de la base de datos
            _context.SaveChanges();  // Guardar los cambios
            return true;
        }
        public string ObtenerEstadoProducto(DateTime fechaCaducidad)
        {
            var hoy = DateTime.Now;
            var tresDias = hoy.AddDays(3);

            if (fechaCaducidad < hoy)
                return "Vencido";
            if (fechaCaducidad <= tresDias)
                return "Por Vencer";
            return "Vigente";
        }

    }

}
