﻿using System;
using System.Linq;
using InventarioAPI.Models;
using InventarioAPI.Data;
using InventarioAPI.DTOs;

namespace InventarioAPI.Services
{
    public class EntradaInventarioService
    {
        private readonly ApplicationDbContext _context;

        public EntradaInventarioService(ApplicationDbContext context)
        {
            _context = context;
        }

        // Este es el único método que deberías tener
        public void CrearEntrada(EntradaInventarioDTO entrada)
        {
            var producto = _context.Producto.FirstOrDefault(p => p.Id == entrada.ProductoId);
            if (producto == null)
            {
                throw new Exception("Producto no encontrado.");
            }

            var entradaInventario = new EntradaInventario
            {
                ProductoId = entrada.ProductoId,
                Cantidad = entrada.Cantidad,
                FechaCaducidad = entrada.FechaCaducidad,
                FechaEntrada = DateTime.Now
            };

            _context.EntradaInventario.Add(entradaInventario);
            _context.SaveChanges();
        }
    }
}
