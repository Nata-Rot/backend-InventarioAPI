﻿using System.Threading.Tasks;
using InventarioAPI.Data;
using InventarioAPI.Models;  // Asegúrate de que esté importado el espacio de nombres correcto
using Microsoft.EntityFrameworkCore;

namespace InventarioAPI.Services
{
    public class UserService
    {
        private readonly ApplicationDbContext _context;

        public UserService(ApplicationDbContext context)
        {
            _context = context;
        }

        public async Task<Usuario> Authenticate(string email, string password)
        {
            // Verifica si el usuario existe en la base de datos y si la contraseña coincide.
            var usuario = await _context.Usuarios
                .FirstOrDefaultAsync(u => u.Email == email && u.PasswordHash == password);

            if (usuario == null)
            {
                return null; // Si no se encuentra el usuario o la contraseña es incorrecta
            }

            // Si es exitoso, puedes devolver el usuario o un token
            return usuario;
        }
    }
}
