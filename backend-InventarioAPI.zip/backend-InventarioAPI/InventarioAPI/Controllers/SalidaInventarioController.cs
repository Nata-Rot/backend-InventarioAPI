﻿using InventarioAPI.DTOs;
using InventarioAPI.Services;
using Microsoft.AspNetCore.Mvc;

namespace InventarioAPI.Controllers
{
    [ApiController]
    [Route("api/[controller]")]
    public class SalidaInventarioController : ControllerBase
    {
        private readonly SalidaInventarioService _salidaService;

        public SalidaInventarioController(SalidaInventarioService salidaService)
        {
            _salidaService = salidaService;
        }

        [HttpPost]
        public ActionResult CrearSalida([FromBody] SalidaInventarioDTO salida)
        {
            try
            {
                Console.WriteLine($"Datos recibidos: ProductoId={salida.ProductoId}, Cantidad={salida.Cantidad}");

                // Llamar al servicio para crear la salida de inventario
                var idSalida = _salidaService.CrearSalida(salida);

                // Retornar información adicional, como un mensaje de éxito, el ID de la salida y los datos procesados
                return Ok(new
                {
                    message = "Salida registrada con éxito",
                    productoId = salida.ProductoId,
                    cantidad = salida.Cantidad,
                    idSalida = idSalida,
                    fechaSalida = DateTime.Now
                });
            }
            catch (Exception ex)
            {
                Console.WriteLine($"Error: {ex.Message}");

                // Retornar error con el mensaje de la excepción
                return BadRequest(new { message = ex.Message });
            }
        }

    }
}
