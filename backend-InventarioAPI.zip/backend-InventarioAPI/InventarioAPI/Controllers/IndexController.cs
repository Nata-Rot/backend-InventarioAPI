﻿using Microsoft.AspNetCore.Mvc;

namespace InventarioAPI.Controllers
{
    [ApiController]
    [Route("api/[controller]")]
    public class IndexController : ControllerBase
    {
        [HttpGet]
        public ActionResult<string> GetWelcomeMessage()
        {
            return Ok("Bienvenido a la API de Inventario.");
        }
    }
}
