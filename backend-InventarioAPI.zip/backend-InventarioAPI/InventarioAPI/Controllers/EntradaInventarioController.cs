﻿using InventarioAPI.Services;
using InventarioAPI.DTOs;
using Microsoft.AspNetCore.Mvc;

namespace GestionInventario.Controllers
{
    [ApiController]
    [Route("api/[controller]")]
    public class EntradaInventarioController : ControllerBase
    {
        private readonly EntradaInventarioService _entradaService;

        public EntradaInventarioController(EntradaInventarioService entradaService)
        {
            _entradaService = entradaService;
        }

        [HttpPost]
        public ActionResult CrearEntrada([FromBody] EntradaInventarioDTO entrada)
        {
            try
            {
                _entradaService.CrearEntrada(entrada);
                return Ok();
            }
            catch (Exception ex)
            {
                return BadRequest(ex.Message);
            }
        }
    }
}
