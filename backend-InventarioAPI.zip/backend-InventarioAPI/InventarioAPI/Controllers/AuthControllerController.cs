﻿using Microsoft.AspNetCore.Mvc;
using InventarioAPI.Services;
using InventarioAPI.Models; // Asegúrate de que esté importado el servicio correcto

namespace InventarioAPI.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class LoginController : ControllerBase
    {
        private readonly UserService _userService;

        public LoginController(UserService userService)
        {
            _userService = userService;
        }

        [HttpPost("login")]
        public async Task<IActionResult> Login([FromBody] LoginRequest request)
        {
            var user = await _userService.Authenticate(request.Email, request.Password);
            if (user == null)
                return Unauthorized("Invalid credentials");

            // Aquí puedes generar un JWT o cualquier otra respuesta
            return Ok(new { message = "Login successful" });
        }
    }
}
