﻿using InventarioAPI.Services;
using InventarioAPI.DTOs;
using Microsoft.AspNetCore.Mvc;
using GestionInventario.Services;

namespace InventarioAPI.Controllers
{
    [ApiController]
    [Route("api/[controller]")]
    public class ProductoController : ControllerBase
    {
        private readonly ProductoService _productoService;

        public ProductoController(ProductoService productoService)
        {
            _productoService = productoService;
        }

        [HttpGet]
        public ActionResult<IEnumerable<ProductoDTO>> GetProductos()
       {
            return Ok(_productoService.GetProductos());
        }

        [HttpGet("{id}")]
        public ActionResult<ProductoDTO> GetProductoById(int id)
        {
            var producto = _productoService.GetProductoById(id);
            if (producto == null)
            {
                return NotFound();
            }
            return Ok(producto);
        }
        [HttpPost]
        public ActionResult<ProductoDTO> CrearProducto([FromBody] ProductoDTO productoDto)
        {
            try
            {
                var productoCreado = _productoService.CrearProducto(productoDto);
                return CreatedAtAction(nameof(GetProductoById), new { id = productoCreado.Id }, productoCreado);
            }
            catch (Exception ex)
            {
                return BadRequest($"Error al crear producto: {ex.Message}");
            }
        }
        [HttpDelete("{id}")]
        public ActionResult EliminarProducto(int id)
        {
            try
            {
                var productoEliminado = _productoService.EliminarProducto(id);
                if (productoEliminado)
                {
                    return NoContent();  // Devuelve un 204 No Content si la eliminación fue exitosa
                }
                return NotFound();  // Devuelve un 404 si el producto no se encuentra
            }
            catch (Exception ex)
            {
                return BadRequest($"Error al eliminar producto: {ex.Message}");
            }
        }

    }

}
